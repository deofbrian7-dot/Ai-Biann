# BIANXYTER AI — Hybrid Android Project

Premium dark Android starter using Kotlin, Jetpack Compose, DataStore and OkHttp.

## Features implemented
- Premium dashboard and bottom navigation
- AI chat for OpenAI-compatible Chat Completions endpoints
- Configurable HTTPS endpoint, model and API key
- Local settings persistence with Preferences DataStore
- Device Center (manufacturer/model, Android release, SDK, battery percentage)
- Smart Notes (in-memory for this starter)
- Clear chat action and loading/error feedback
- GitHub Actions workflow to build and upload a debug APK

## Build APK on GitHub
1. Create a new GitHub repository.
2. Upload/push the contents of this project to the repository root.
3. Open the repository's **Actions** tab.
4. Select **Build Bianxyter AI APK** and click **Run workflow**, or push to `main`/`master`.
5. Open the completed workflow run and download the artifact named `BIANXYTER-AI-debug-apk`.
6. Extract the artifact ZIP to get `app-debug.apk`.

The workflow uses JDK 17, Gradle 8.9, Android SDK 35 and builds `assembleDebug`.

## Build locally
Open in Android Studio with JDK 17 and Android SDK 35, then run:
`gradle assembleDebug`

## AI provider
In the app, open Settings and enter:
- An HTTPS OpenAI-compatible Chat Completions endpoint
- A model name supported by that provider
- An API key

The chat sends the current prompt to the configured endpoint. This starter currently sends each prompt as a standalone request; it does not yet send the full previous chat transcript as context.

## Important production notes
- This is a source project with a GitHub Actions build workflow, not a prebuilt or signed release APK.
- API key is stored locally using Preferences DataStore for prototype convenience. Do not distribute a public APK with a personal provider key. For production, proxy AI requests through a backend you control and use proper authentication/rate limits.
- Smart Notes and chat history are currently in-memory and reset when the app process is restarted.
- Device Center is read-only. It does not change CPU/GPU, refresh rate, thermal settings, or Android power restrictions.
- AI image generation, voice input, accounts/cloud sync, and admin dashboard are not implemented in this starter.
