package com.bianxyter.ai.ui

import android.content.Context
import android.os.BatteryManager
import android.os.Build
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.bianxyter.ai.data.AppSettings

private val Bg = Color(0xFF080D18)
private val Card = Color(0xFF121D2E)
private val Accent = Color(0xFF79C9FF)
private val Muted = Color(0xFF9AAAC1)
private val Txt = Color(0xFFF3F7FC)

@Composable
fun BianxyterApp(
    settings: AppSettings,
    onSaveSettings: (AppSettings) -> Unit,
    onSendMessage: (String) -> Unit,
    onClearChat: () -> Unit,
    onSaveNote: (String, String) -> Unit,
    onDeleteNote: (Long) -> Unit
) {
    var page by remember { mutableStateOf("Home") }
    MaterialTheme(colorScheme = darkColorScheme(primary = Accent, background = Bg, surface = Card, onBackground = Txt, onSurface = Txt)) {
        Scaffold(
            containerColor = Bg,
            bottomBar = {
                NavigationBar(containerColor = Card) {
                    listOf("Home", "AI Chat", "Tools", "Notes", "Settings").forEach { item ->
                        val icon = when (item) {
                            "Home" -> Icons.Default.Home
                            "AI Chat" -> Icons.Default.Chat
                            "Tools" -> Icons.Default.Build
                            "Notes" -> Icons.Default.Notes
                            else -> Icons.Default.Settings
                        }
                        NavigationBarItem(
                            selected = page == item,
                            onClick = { page = item },
                            icon = { Icon(icon, contentDescription = item) },
                            label = { Text(item, fontSize = 10.sp) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = Accent, selectedTextColor = Accent,
                                indicatorColor = Color(0xFF20364E),
                                unselectedIconColor = Muted, unselectedTextColor = Muted
                            )
                        )
                    }
                }
            }
        ) { padding ->
            Box(Modifier.fillMaxSize().padding(padding)) {
                when (page) {
                    "Home" -> HomeScreen(
                        goChat = { page = "AI Chat" },
                        goTools = { page = "Tools" },
                        goNotes = { page = "Notes" }
                    )
                    "AI Chat" -> ChatScreen(onSendMessage, onClearChat)
                    "Tools" -> ToolsScreen()
                    "Notes" -> NotesScreen(onSaveNote, onDeleteNote)
                    else -> SettingsScreen(settings, onSaveSettings)
                }
            }
        }
    }
}

@Composable
private fun ScreenTitle(title: String, subtitle: String) {
    Column(Modifier.padding(bottom = 18.dp)) {
        Text(title, color = Txt, fontSize = 25.sp, fontWeight = FontWeight.Bold)
        Text(subtitle, color = Muted, fontSize = 12.sp)
    }
}

@Composable
private fun HomeScreen(goChat: () -> Unit, goTools: () -> Unit, goNotes: () -> Unit) {
    Column(Modifier.fillMaxSize().background(Bg).padding(18.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Surface(color = Color(0xFF1D3D5B), shape = RoundedCornerShape(14.dp)) {
                Icon(Icons.Default.AutoAwesome, null, tint = Accent, modifier = Modifier.padding(11.dp).size(25.dp))
            }
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text("BIANXYTER AI", color = Txt, fontWeight = FontWeight.ExtraBold, fontSize = 18.sp)
                Text("PREMIUM HYBRID ASSISTANT", color = Accent, fontSize = 9.sp, letterSpacing = 1.sp)
            }
            Surface(color = Color(0xFF153A32), shape = RoundedCornerShape(30.dp)) {
                Text("● READY", Modifier.padding(horizontal = 10.dp, vertical = 6.dp), color = Color(0xFF75E0B1), fontSize = 9.sp)
            }
        }
        Spacer(Modifier.height(24.dp))
        Box(Modifier.fillMaxWidth().background(Brush.linearGradient(listOf(Color(0xFF1D4263), Color(0xFF171D38))), RoundedCornerShape(24.dp)).padding(21.dp)) {
            Column {
                Text("YOUR AI. YOUR WORLD.", color = Accent, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.4.sp)
                Spacer(Modifier.height(8.dp))
                Text("Halo, Bianxyter!", color = Txt, fontSize = 27.sp, fontWeight = FontWeight.Bold)
                Text("Satu aplikasi untuk ide, AI, dan tools.", color = Color(0xFFC0D0E3), fontSize = 12.sp)
                Spacer(Modifier.height(16.dp))
                Button(onClick = goChat, colors = ButtonDefaults.buttonColors(containerColor = Accent), shape = RoundedCornerShape(12.dp)) {
                    Text("Mulai AI Chat", color = Bg, fontWeight = FontWeight.Bold)
                    Icon(Icons.Default.ArrowForward, null, tint = Bg, modifier = Modifier.padding(start = 7.dp))
                }
            }
        }
        Spacer(Modifier.height(22.dp))
        Text("QUICK ACCESS", color = Muted, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.4.sp)
        Spacer(Modifier.height(10.dp))
        FeatureRow("AI Assistant", "Tanya jawab dengan model AI", Icons.Default.Chat, goChat)
        FeatureRow("Device Center", "Informasi perangkat Android", Icons.Default.PhoneAndroid, goTools)
        FeatureRow("Smart Notes", "Simpan catatan dan prompt", Icons.Default.Notes, goNotes)
        FeatureRow("Code Helper", "Bantuan konsep dan kode", Icons.Default.Code, goChat)
        Spacer(Modifier.weight(1f))
        Text("BIANXYTER AI • VERSION 2.0.0", color = Color(0xFF65758B), fontSize = 9.sp, modifier = Modifier.align(Alignment.CenterHorizontally))
    }
}

@Composable
private fun FeatureRow(title: String, subtitle: String, icon: androidx.compose.ui.graphics.vector.ImageVector, click: () -> Unit) {
    Surface(Modifier.fillMaxWidth().padding(bottom = 9.dp).clickable(onClick = click), color = Card, shape = RoundedCornerShape(16.dp)) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, null, tint = Accent, modifier = Modifier.size(24.dp))
            Spacer(Modifier.width(13.dp))
            Column(Modifier.weight(1f)) {
                Text(title, color = Txt, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                Text(subtitle, color = Muted, fontSize = 10.sp)
            }
            Icon(Icons.Default.ChevronRight, null, tint = Muted)
        }
    }
}

@Composable
private fun ChatScreen(send: (String) -> Unit, clear: () -> Unit) {
    val context = LocalContext.current
    val vm = androidx.lifecycle.viewmodel.compose.viewModel<BianxyterViewModel>()
    val messages by vm.messages.collectAsState()
    val loading by vm.loading.collectAsState()
    val error by vm.chatError.collectAsState()
    var input by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().background(Bg).padding(15.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) { ScreenTitle("AI Chat", "Chat dengan model AI pilihanmu") }
            IconButton(onClick = clear) { Icon(Icons.Default.DeleteSweep, "Clear chat", tint = Muted) }
        }
        LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(9.dp)) {
            items(messages) { message ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = if (message.fromUser) Arrangement.End else Arrangement.Start) {
                    Surface(color = if (message.fromUser) Color(0xFF1D4565) else Card, shape = RoundedCornerShape(15.dp), modifier = Modifier.widthIn(max = 310.dp)) {
                        Text(message.text, Modifier.padding(12.dp), color = Txt, fontSize = 13.sp)
                    }
                }
            }
            if (loading) item { Text("Bianxyter AI sedang berpikir…", color = Accent, fontSize = 11.sp) }
        }
        error?.let { Text(it, color = Color(0xFFFFA3A3), fontSize = 11.sp, modifier = Modifier.padding(bottom = 6.dp)) }
        Row(Modifier.fillMaxWidth().background(Card, RoundedCornerShape(17.dp)).padding(7.dp), verticalAlignment = Alignment.CenterVertically) {
            BasicTextField(
                value = input, onValueChange = { input = it }, modifier = Modifier.weight(1f).padding(10.dp),
                textStyle = androidx.compose.ui.text.TextStyle(color = Txt, fontSize = 13.sp),
                decorationBox = { inner -> if (input.isEmpty()) Text("Tulis pesan…", color = Muted, fontSize = 13.sp); inner() }
            )
            IconButton(onClick = { if (input.isNotBlank() && !loading) { send(input); input = "" } }) {
                Icon(Icons.Default.Send, "Kirim", tint = Accent)
            }
        }
        Text("Hindari mengirim data pribadi atau rahasia.", color = Muted, fontSize = 9.sp, modifier = Modifier.padding(top = 6.dp))
    }
}

@Composable
private fun ToolsScreen() {
    val context = LocalContext.current
    val batteryManager = remember { context.getSystemService(Context.BATTERY_SERVICE) as BatteryManager }
    val battery = remember { batteryManager.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY) }
    Column(Modifier.fillMaxSize().background(Bg).padding(18.dp)) {
        ScreenTitle("Device Center", "Informasi perangkat • mode baca saja")
        DeviceInfo("Perangkat", "${Build.MANUFACTURER} ${Build.MODEL}", Icons.Default.PhoneAndroid)
        DeviceInfo("Android", "Android ${Build.VERSION.RELEASE}", Icons.Default.Android)
        DeviceInfo("SDK level", Build.VERSION.SDK_INT.toString(), Icons.Default.Info)
        DeviceInfo("Baterai", if (battery in 0..100) "$battery%" else "Tidak tersedia", Icons.Default.BatteryFull)
        DeviceInfo("Aplikasi", "Bianxyter AI 2.0.0", Icons.Default.Apps)
        Spacer(Modifier.height(8.dp))
        Text("Device Center tidak mengubah CPU, GPU, refresh rate, atau batasan sistem. Ini mencegah perubahan perangkat tanpa izin dan mengurangi risiko.", color = Muted, fontSize = 11.sp)
    }
}

@Composable
private fun DeviceInfo(label: String, value: String, icon: androidx.compose.ui.graphics.vector.ImageVector) {
    Surface(Modifier.fillMaxWidth().padding(bottom = 9.dp), color = Card, shape = RoundedCornerShape(15.dp)) {
        Row(Modifier.padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, null, tint = Accent, modifier = Modifier.size(23.dp))
            Spacer(Modifier.width(13.dp))
            Column {
                Text(label, color = Muted, fontSize = 10.sp)
                Text(value, color = Txt, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
            }
        }
    }
}

@Composable
private fun NotesScreen(save: (String, String) -> Unit, delete: (Long) -> Unit) {
    val vm = androidx.lifecycle.viewmodel.compose.viewModel<BianxyterViewModel>()
    val notes by vm.notes.collectAsState()
    var title by remember { mutableStateOf("") }
    var body by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().background(Bg).padding(18.dp)) {
        ScreenTitle("Smart Notes", "Catatan dan prompt singkat")
        OutlinedTextField(title, { title = it }, label = { Text("Judul") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(body, { body = it }, label = { Text("Isi catatan") }, modifier = Modifier.fillMaxWidth(), minLines = 3)
        Spacer(Modifier.height(8.dp))
        Button(onClick = { save(title, body); title = ""; body = "" }, enabled = title.isNotBlank() && body.isNotBlank(), colors = ButtonDefaults.buttonColors(containerColor = Accent)) {
            Text("Simpan catatan", color = Bg)
        }
        Spacer(Modifier.height(16.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(notes, key = { it.id }) { note ->
                Surface(color = Card, shape = RoundedCornerShape(14.dp)) {
                    Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(note.title, color = Txt, fontWeight = FontWeight.Bold)
                            Text(note.body, color = Muted, fontSize = 12.sp)
                        }
                        IconButton(onClick = { delete(note.id) }) { Icon(Icons.Default.Delete, "Hapus", tint = Color(0xFFFF9292)) }
                    }
                }
            }
        }
    }
}

@Composable
private fun SettingsScreen(settings: AppSettings, save: (AppSettings) -> Unit) {
    var endpoint by remember(settings.endpoint) { mutableStateOf(settings.endpoint) }
    var model by remember(settings.model) { mutableStateOf(settings.model) }
    var key by remember(settings.apiKey) { mutableStateOf(settings.apiKey) }
    Column(Modifier.fillMaxSize().background(Bg).padding(18.dp)) {
        ScreenTitle("Settings", "Atur koneksi AI dan tampilan")
        Text("AI PROVIDER", color = Accent, fontSize = 10.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(endpoint, { endpoint = it }, label = { Text("API endpoint HTTPS") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(model, { model = it }, label = { Text("Model") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(key, { key = it }, label = { Text("API key") }, modifier = Modifier.fillMaxWidth(), singleLine = true, visualTransformation = PasswordVisualTransformation())
        Spacer(Modifier.height(8.dp))
        Text("Endpoint harus kompatibel dengan OpenAI Chat Completions. API key disimpan lokal untuk prototipe; untuk rilis publik gunakan backend sendiri agar key tidak tertanam di APK.", color = Muted, fontSize = 10.sp)
        Spacer(Modifier.height(15.dp))
        Spacer(Modifier.height(15.dp))
        Button(
            onClick = { save(AppSettings(endpoint.trim(), model.trim(), key.trim(), settings.darkMode)) },
            enabled = endpoint.startsWith("https://") && model.isNotBlank(),
            colors = ButtonDefaults.buttonColors(containerColor = Accent)
        ) { Text("Simpan pengaturan", color = Bg, fontWeight = FontWeight.Bold) }
        Spacer(Modifier.height(18.dp))
        Text("BIANXYTER AI • v2.0.0", color = Muted, fontSize = 10.sp)
    }
}
