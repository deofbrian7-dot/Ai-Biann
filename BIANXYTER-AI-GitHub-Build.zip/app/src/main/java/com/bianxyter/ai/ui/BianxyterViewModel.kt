package com.bianxyter.ai.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.bianxyter.ai.data.AppSettings
import com.bianxyter.ai.data.ChatRepository
import com.bianxyter.ai.data.SettingsStore
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class ChatMessage(val text: String, val fromUser: Boolean)
data class NoteItem(val id: Long, val title: String, val body: String)

class BianxyterViewModel(app: Application) : AndroidViewModel(app) {
    private val store = SettingsStore(app)
    private val repository = ChatRepository()
    val settings = store.settings.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), AppSettings())

    val messages = kotlinx.coroutines.flow.MutableStateFlow(
        listOf(ChatMessage("Halo! Aku Bianxyter AI. Ada yang bisa aku bantu?", false))
    )
    val notes = kotlinx.coroutines.flow.MutableStateFlow<List<NoteItem>>(emptyList())
    val loading = kotlinx.coroutines.flow.MutableStateFlow(false)
    val chatError = kotlinx.coroutines.flow.MutableStateFlow<String?>(null)

    fun saveSettings(value: AppSettings) = viewModelScope.launch { store.save(value) }

    fun sendMessage(text: String) {
        val prompt = text.trim()
        if (prompt.isEmpty() || loading.value) return
        messages.value = messages.value + ChatMessage(prompt, true)
        chatError.value = null
        loading.value = true
        viewModelScope.launch {
            repository.ask(settings.value, prompt)
                .onSuccess { messages.value = messages.value + ChatMessage(it, false) }
                .onFailure { chatError.value = it.message ?: "Terjadi kesalahan." }
            loading.value = false
        }
    }

    fun clearChat() {
        messages.value = listOf(ChatMessage("Percakapan baru dimulai. Ada yang bisa aku bantu?", false))
        chatError.value = null
    }

    fun saveNote(title: String, body: String) {
        if (title.isBlank() || body.isBlank()) return
        notes.value = listOf(NoteItem(System.currentTimeMillis(), title.trim(), body.trim())) + notes.value
    }

    fun deleteNote(id: Long) { notes.value = notes.value.filterNot { it.id == id } }
}
