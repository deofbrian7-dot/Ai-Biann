package com.bianxyter.ai.data

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "bianxyter_settings")

class SettingsStore(private val context: Context) {
    private object Keys {
        val endpoint = stringPreferencesKey("endpoint")
        val model = stringPreferencesKey("model")
        val apiKey = stringPreferencesKey("api_key")
        val darkMode = booleanPreferencesKey("dark_mode")
    }

    val settings: Flow<AppSettings> = context.dataStore.data.map { p ->
        AppSettings(
            endpoint = p[Keys.endpoint] ?: AppSettings().endpoint,
            model = p[Keys.model] ?: AppSettings().model,
            apiKey = p[Keys.apiKey] ?: "",
            darkMode = p[Keys.darkMode] ?: true
        )
    }

    suspend fun save(value: AppSettings) {
        context.dataStore.edit { p ->
            p[Keys.endpoint] = value.endpoint
            p[Keys.model] = value.model
            p[Keys.apiKey] = value.apiKey
            p[Keys.darkMode] = value.darkMode
        }
    }
}
