package com.bianxyter.ai.data

data class AppSettings(
    val endpoint: String = "https://api.openai.com/v1/chat/completions",
    val model: String = "gpt-4o-mini",
    val apiKey: String = "",
    val darkMode: Boolean = true
)
