package com.bianxyter.ai.data

import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

class ChatRepository {
    private val client = OkHttpClient.Builder()
        .callTimeout(60, TimeUnit.SECONDS)
        .build()

    fun ask(settings: AppSettings, prompt: String): Result<String> = runCatching {
        require(settings.apiKey.isNotBlank()) { "Isi API key di Pengaturan terlebih dahulu." }
        require(settings.endpoint.startsWith("https://")) { "Endpoint harus menggunakan HTTPS." }
        val messages = JSONArray()
            .put(JSONObject().put("role", "system").put("content", "Kamu adalah Bianxyter AI, asisten yang ramah, jelas, dan aman."))
            .put(JSONObject().put("role", "user").put("content", prompt))
        val payload = JSONObject()
            .put("model", settings.model)
            .put("messages", messages)
            .put("temperature", 0.7)
        val body = payload.toString().toRequestBody("application/json; charset=utf-8".toMediaType())
        val request = Request.Builder()
            .url(settings.endpoint)
            .header("Authorization", "Bearer ${settings.apiKey}")
            .post(body)
            .build()
        client.newCall(request).execute().use { response ->
            val raw = response.body?.string().orEmpty()
            if (!response.isSuccessful) {
                val detail = runCatching { JSONObject(raw).optJSONObject("error")?.optString("message") }.getOrNull()
                error(detail?.takeIf { it.isNotBlank() } ?: "Permintaan gagal (HTTP ${response.code}).")
            }
            JSONObject(raw).optJSONArray("choices")
                ?.optJSONObject(0)?.optJSONObject("message")
                ?.optString("content")?.takeIf { it.isNotBlank() }
                ?: error("Respons dari server AI kosong atau formatnya tidak dikenali.")
        }
    }
}
