package com.bianxyter.ai

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.lifecycle.viewmodel.compose.viewModel
import com.bianxyter.ai.ui.BianxyterApp
import com.bianxyter.ai.ui.BianxyterViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val vm: BianxyterViewModel = viewModel()
            val settings by vm.settings.collectAsState()
            BianxyterApp(
                settings = settings,
                onSaveSettings = vm::saveSettings,
                onSendMessage = vm::sendMessage,
                onClearChat = vm::clearChat,
                onSaveNote = vm::saveNote,
                onDeleteNote = vm::deleteNote
            )
        }
    }
}
